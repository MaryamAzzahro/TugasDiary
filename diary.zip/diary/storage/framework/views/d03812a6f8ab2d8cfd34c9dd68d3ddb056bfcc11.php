<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <div class="row justify-content-center">
            <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Edit Diary</div>

                        <div class="card-body">
                            <form method="post" action="<?php echo e(route('diary.update', $contents)); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>

                                <div class="form-group">

                                    <label for="">Title</label>
                                    <input type="text" class="form-control" id="title" name="title" placeholder="...." value="<?php echo e($contents->title); ?>">
                                    
                                </div>
                                <div class="form-group">

                                    <label for="">Description</label>
                                    <textarea name="description" id="description" rows="10" class="form-control" placeholder="...."><?php echo e($contents->description); ?></textarea>

                                </div>
                            
                                <button type="submit" class="btn btn-primary d-flex ml-auto">Save</button>
                            </form>
                        </div>
                    </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diary\resources\views/diary/edit.blade.php ENDPATH**/ ?>