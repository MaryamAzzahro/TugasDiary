<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

    <title>E_Diary</title>
</head>
<body>
    <h1>My Diary</h1>

    <form action="#">
        <div class="form">
            <label for="title">Title</label>
            <br>
            <input type="text" name = "form_title" placeholder ="Type your Tittle">
        </div>
        <div class="fom">
            <label for="content">Content</label>
            <br>
            <textarea name="content" id="" cols="30" rows="10"></textarea>
        </div>
        <br>
        
       <input type="submit" name="send" value="send" >
    </form>
</body>


</html><?php /**PATH C:\xampp\htdocs\diary\resources\views/create.blade.php ENDPATH**/ ?>