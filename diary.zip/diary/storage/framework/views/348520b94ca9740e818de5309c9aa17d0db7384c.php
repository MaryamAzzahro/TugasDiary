<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card <?php echo e($loop->index+1 !== count($contents) ? 'mb-4' : ''); ?>">
                        <div class="card-header">
                            <?php echo e($content -> title); ?>

                        </div>

                        <div class="card-body">
                           <p><?php echo e($content -> description); ?></p>

                           <div class="d-flex justify-content-end">
                                     <!-- btn edit -->
                                     <a href="<?php echo e(route('diary.edit', $content->id)); ?>" class="btn btn-success mr-3">
                                        Edit
                                     </a>
                                     <form action="<?php echo e(route('diary.destroy' , $content)); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" onclick="return confirm('Are you sure you want to delete this item?');" class= "btn btn-danger" id="btn-delete">Delete</button>
                                    </form>
                           </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diary\resources\views/diary/index.blade.php ENDPATH**/ ?>