<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <div class="row justify-content-center">
            <div class="col-8">
                <div class="card">
                <div class="card-header">
                    Create Your Diary
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo e(route('diary.store')); ?>">
                    <?php echo e(csrf_field()); ?>

                        <div class="form-group">

                            <label for="">Title</label>
                            <input type="text" class="form-control" id="title" name="title" placeholder="...." >
                            
                        </div>
                        <div class="form-group">

                            <label for="">Description</label>
                            <textarea name="description" id="description"rows="10" class="form-control" placeholder="...."></textarea>

                        </div>
                    
                        <button type="submit" class="btn btn-primary d-flex ml-auto">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diary\resources\views/diary/create.blade.php ENDPATH**/ ?>