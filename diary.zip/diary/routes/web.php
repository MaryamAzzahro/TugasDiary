<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/content', 'ContentController@index')->name('diary.index');
Route::get('/content/create', 'ContentController@create')->name('diary.create');
Route::post('/content/create', 'ContentController@store')->name('diary.store');
Route::get('/content/{content}/edit', 'ContentController@edit')->name('diary.edit');
Route::patch('/content/{content}/edit', 'ContentController@update')->name('diary.update');
Route::delete('/content/{content}/delete', 'ContentController@destroy')->name('diary.destroy');


Route::get('/create', function () {
    return view('create');
});
