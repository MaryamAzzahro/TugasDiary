@extends('layouts.master')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                @foreach ($contents as $content)
                    <div class="card {{ $loop->index+1 !== count($contents) ? 'mb-4' : '' }}">
                        <div class="card-header">
                            {{ $content -> title }}
                        </div>

                        <div class="card-body">
                           <p>{{ $content -> description }}</p>

                           <div class="d-flex justify-content-end">
                                     <!-- btn edit -->
                                     <a href="{{ route('diary.edit', $content->id) }}" class="btn btn-success mr-3">
                                        Edit
                                     </a>
                                     <form action="{{ route('diary.destroy' , $content) }}" method="post">
                                        {{ csrf_field() }}
                                        {{ method_field('DELETE') }}
                                        <button type="submit" onclick="return confirm('Are you sure you want to delete this item?');" class= "btn btn-danger" id="btn-delete">Delete</button>
                                    </form>
                           </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endsection