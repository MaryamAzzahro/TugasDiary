<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Content;

class ContentController extends Controller
{
    public function index()
    {
        $contents = Content::all();

        return view('diary.index', compact('contents'));
    }

    public function create()
    {
        return view('diary.create');
    }
    
    public function store(Request $request)
    {
       Content::create([
            'title' => $request -> title,
            'description' => $request -> description
       ]);

       return redirect()->route('diary.index');


    }

    public function edit($id)
    {
        $contents = Content::all();
        $contents = Content::find($id);

        return view('diary.edit',compact('contents'));
    }

    public function update(Content $content)
    {

        $content->update([
            'title' => request('title'),
            'description' => request('description')
        ]);

        return redirect()->route('diary.index');
    }

    public function destroy(Content $content)
    {
        $content->delete();

        return redirect()->route('diary.index');
    }
}
